---
name: scope-verify
description: "Verify one exact ready IIS Scope against a stable current implementation target, adjudicating every authored Acceptance scenario and product success condition from sufficient discriminating evidence. Exactly one independent verifier owns each semantic cycle; successful verification is followed by caller-owned Production Heuristic Probe before completion recording."
---

# Scope Verify

## Caller contract

The caller provides one complete source assignment before role-specific instructions:

- **Project Root:** exact canonical absolute path.
- **Thesis:** every exact Scope-bound project-local Thesis source, recorded revision and full UTF-8 SHA-256.
- **Scope:** exact canonical `docs/planning/work/<slug>/SCOPE.md` path.
- **Transition Authority:** if the exact Scope contains the optional section, preserve each exact project-local baseline path and full SHA-256 and verify the selected Block/conditions during semantic preflight; if absent, no baseline is required. A digest proves bytes, not approval or continuation authority.
- **Plan Review:** `None` or exact outside-root method review path. For a normal delivery handoff, preserve its unchanged rationale/findings/conditions, including implementation-grounded frontier navigation, executable discriminator basis and load-bearing evidence locators; it is not verification authority or a substitute for independent as-built assessment. Applicable admission evidence remains required for corrective continuation below.
- **Implementation evidence:** exact current target/report/readback references, or `None supplied` for standalone verification. After correction in this request, supply the actual mutation attribution, current authorized actor/model/effort/mode and completed implementation result with admission and self-check evidence, predecessor finding/reproducer or exact limit, regression/durable-reproducer disposition, same-assumption sibling basis and non-obvious build/command/fixture/readback/reset/cleanup handoff.
- **Known findings:** exact predecessor Verify/Probe result, finding, primary evidence, usable reproducer or evidence limit and correction/new evidence, or `None`.
- **User instructions:** current permitted actions, readbacks, external conditions and selected verifier model/effort.
- **Independent Verifier:** exact separate invocation/worker identity and result destination; the verifier is not the implementing actor or Main relabeling its own judgment.
- **Role source identity:** exact readable `scope-verify` entry/reference paths from the supplied source or installed snapshot. A repository or installation claim alone does not prove this invocation loaded them.

Tell the worker: **read every bound Thesis source and the exact Scope directly before semantic judgment, including purpose, complete product loop, false-success distinctions, failure/recovery, identity/truth boundaries and product success observations.** Caller summaries and implementation narration are navigation, not authority or proof. Bound originals do not authorize remediation or Scope expansion.

### Evidence boundary — copy into the verifier assignment

> **Evidence boundary — apply before role-specific work**
> - Do not use mocks, stubs, canned responses, seeded success states or surrogate readbacks as evidence for a real boundary they replace.
> - When the Scope promises real execution, state transitions or external effects, exercise the real path and authoritative readback. Internal success or HTTP acceptance alone cannot prove the product result.
> - A double for an ancillary dependency does not invalidate observation of an unrelated real boundary. Name which boundary was actually observed and which was replaced.
> - If required evidence is unavailable, preserve the gap as `INCONCLUSIVE` or the applicable non-started result. Do not infer success or use unauthorized actions.

Forward this block unchanged and append exact role documents, target hints, predecessor/correction evidence when applicable, result destination and authority limits. The worker never repairs product source, dispatches the Production Heuristic Probe or records Scope completion.

## Purpose and ownership

Exactly one independent verifier owns the complete semantic cycle for this Scope: canonical admission, original-meaning preflight, every authored Acceptance scenario, independent as-built failure-frontier assessment, derived discriminating execution where necessary, authoritative readback, known-finding disposition, conditional evidence retention, settlement, cleanup and one semantic verdict (`VERIFIED`, `FAILED` or `INCONCLUSIVE`).

The caller Main owns dispatch, completed-result fan-in, worker/process settlement, post-success Production Heuristic Probe and completion recording. Main does not perform a second semantic verdict. The Probe is a separate bounded residual heuristic/evidence search after a successful verifier result and never replaces the verifier's Acceptance judgment or resolves a known material evidence gap on the verifier's behalf. The verifier never edits product source, Thesis, Scope or prior evidence; it may record its own fresh observations and perform only authorized scenario effects and cleanup.

## Inputs and dispatch

Normal delivery verification requires exact `Status: ready`. `draft`, `blocked` or `superseded` do not start. `done` is allowed only for explicitly authorized diagnostic re-verification and cannot reopen or rewrite status. If Scope/Thesis/applicable Transition or stable target changes during the cycle, stop progression and require a fresh cycle against the current originals.

Resolve `scope-verify/SKILL.md`, `scope-verify/references/verify.md` and the canonical Scope validator from the same supplied source or installed skills snapshot and pass exact readable paths. Reports guide target resolution, not semantic judgment; the verifier resolves actual stable implementation targets, as-built failure assumptions and scenario-effect paths itself. When a current Plan Review is supplied, read it as navigation and compare it with the current implementation rather than inheriting its candidate set, executable-test claim or exclusion basis. Genuine standalone verification-only requires no Plan, Plan Review or historical implementation provenance.

Known project verification-tool paths and usage may travel with existing implementation evidence/navigation; they are not new required inputs or proof. Reuse them under `references/verify.md` only after inspecting what they actually execute, their current tool/build/runtime identity, required initial state, readback, reset and cleanup boundary.

For corrective continuation within this request after product or shared verification-tooling repair, confirm actual mutation attribution and a completed result from the currently authorized implementation/tooling actor, including applicable admission and self-check. Read the predecessor finding and primary evidence, usable reproducer or exact limitation, regression/durable-reproducer disposition, same-assumption sibling basis and execution handoff. Missing attribution, inaccessible load-bearing evidence or unauthorized correction returns the existing non-started authority/evidence limitation, not product FAILED, and prevents normal-success progression. A report label, later self-check or renaming the same continuation verification-only cannot retroactively authorize mutation. Declared authorized verifier scenario effects are not implementation corrections.

Arrange **exactly one** separate independent invocation with the selected verifier model/effort, using the available delegation or session facilities. `SUBAGENT` is a role arrangement, not a requirement for a particular tool, profile or patched host. There is no DIRECT self-verification, nested verifier, fallback roster or hidden fan-out. If a genuinely independent invocation or necessary execution capability is unavailable, return the exact limitation without product/runtime/status mutation; do not silently substitute Main or the implementer.

Preserve the actual completed invocation's identity, unchanged result and primary evidence references. A copied report, field set, file digest or success label alone cannot establish independence or truth. This is a skill-governed procedure, not host-enforced authentication or a portable completion credential.

## Target attribution and semantic cycle

Before any product/runtime scenario action, use ordinary read/search/hash/CLI tools to record the exact Project Root, Scope and bound Thesis/applicable Transition paths and actual-byte SHA-256, current ready status, actual stable implementation targets and their byte/runtime identities, declared scenario-effect paths and authorized effects. Record these in the invocation's report/evidence, not a new binding store or protocol. Separate mutable scenario state from stable source/config/authority; do not allow scenario paths to conceal edits to those stable inputs.

Use ordinary inspection/read/CLI/service/runtime tools. Recheck authority and stable target identity after execution and cleanup, including relevant runtime identity; only declared authorized scenario effects may differ. Unexplained drift, missing attribution or unknown settlement prevents successful progression. Do not edit product source/config/planning/prior evidence to obtain a pass. Settled nonzero commands are evidence for that command, not generic workflow uncertainty.

Apply this same identity/currentness discipline to verification scripts, configuration and execution mechanisms that materially determine the verdict. Bind what actually ran and its target in existing evidence, not the tool's entire dependency tree; use the reference's mechanism-drift and return rules. Distinguish reusable execution method and stable preparation resources from scenario state: reusing a build, command recipe or isolated service never carries forward the prior initial state, effect result or product success.

The verifier checks every authored Acceptance scenario and every product success/failure/preservation condition that the Scope makes applicable. A happy path, test count, source shape, internal state or implementation report cannot replace a required real boundary. If a material contract gap prevents the Scope Acceptance from deciding its own result, return a non-started/non-progressing result to Main for the exact owning original under `iis-workflow`'s re-entry rules; do not author a substitute obligation.

A current implementation-grounded counterexample that tests an existing promise is not a new product requirement merely because the authored Acceptance examples did not name that exact trace. Conversely, a new duration, availability, recovery or policy distinction remains product authority and cannot be invented by verification. Follow `references/verify.md` for this boundary. If a known material failure assumption cannot be distinguished from the conforming result with current evidence, broaden acquisition or preserve the exact evidence limit; do not issue `VERIFIED` on the expectation that the later Probe may find it.

After stable product target change, regaining VERIFIED requires one fresh whole-Scope verdict on the exact current target; never compose PASS results from different targets. The fresh verdict re-adjudicates every obligation but does not require mechanical replay of every prior observation. For corrective re-entry, begin evidence acquisition with the predecessor discriminator, changed assumption and directly dependent boundaries, then independently decide current applicability of prior primary evidence for the remaining obligations. The verifier, not Main, the implementer or Probe, chooses sufficient evidence acquisition. Under the reference's changed-target retention rule, a directly readable prior primary observation may support an obligation only when its original target/invocation attribution is preserved and current applicability is independently re-established from the actual changed dependencies and premises; it never becomes current-target execution or a carried-forward PASS. Noninterference alone cannot replace a required real-boundary observation, and a fresh readback of an older result does not prove the current implementation produced it.

For an uncertain non-idempotent or external effect, do not blind replay. Use the authored authoritative readback, settlement and cleanup. Applied/not-applied may be adjudicated when attributable; unknown settlement keeps affected evidence `INCONCLUSIVE`.

A still-running verifier may correct an invocation-local argument/selector/route usage error inside the same invocation only under the narrow conditions in `references/verify.md`: unchanged target/contract/shared mechanism/assertion/observation boundary, no effect or attributable settlement from the invalid attempt, and preservation of both attempts. This does not reopen a completed result, repair shared tooling, relax a decision boundary or evade a contradiction.

## Completed-result fan-in, Probe and recording

Wait for the exact completed independent invocation's result through the available result-delivery mechanism. Routine messages, partial reports and a process exit alone are not semantic completion. Do not poll normal progress or duplicate the verifier's repository/runtime work. Replacement on the same mutable/effect surface requires evidence that the prior worker/process/service settled and a fresh current-target cycle; cancellation receipt is not settlement.

For a completed `VERIFIED` result on a ready Scope, Main obtains exactly one independent `production-heuristic-probing` result after settlement. Pass the unchanged verifier result, primary evidence and current target/source identities; for corrective follow-up also pass the predecessor Probe finding/reproducer, implementation regression disposition, directly connected sibling basis and verifier fresh/retained evidence boundary. Never prescribe a no-finding result. The Probe may use only the bounded safe actions authorized by its own contract and cannot mutate the stable target or non-disposable production state. Its completed result must record the actual independent Probe invocation, actions and primary evidence, durable reproducer handoff for material findings, effect paths, before/after stable target/runtime identity, cleanup and settlement, and Scope-material versus out-of-scope findings and limitations. `FAILED`, `INCONCLUSIVE`, non-started, missing or incomplete verifier results skip the normal-success Probe and cannot progress Scope status.

Only Probe `COMPLETE` with attributable invocation/actions/evidence/currentness, all Probe effects demonstrably settled, and no unresolved Scope-material finding or limitation permits completion recording. A missing or ambiguous action/reproducer/effect/currentness/cleanup record is itself a material completion limit when it prevents attribution or correction handoff; Main does not infer that an omitted effect was absent or settled. Immediately before recording, Main confirms the verifier and Probe results are attributable to their actual separate completed invocations, all required verifier and Probe effects settled, current user authority still permits completion, and the exact Scope remains `ready` with unchanged verified bytes. Recompute actual-byte hashes for bound originals and stable files, and check relevant runtime/effect readbacks against the verifier and Probe recorded postconditions. A hash or file presence alone is not independence or semantic success. Drift or any material gap withholds recording and routes to the exact owner; Main does not rewrite the Plan or issue a second semantic verdict.

When these conditions hold, Main uses ordinary file-edit tools to change only the exact Scope's single `Status: ready` item to `Status: done`, then reads it back and confirms the intended status-only change and canonical validity. Preserve the original verifier verdict, complete Probe result, pre-write Scope identity and actual write/readback evidence in the completion response or existing result artifact. Do not rewrite either independent result or create a new completion store. If the edit/readback is unavailable or unexpected, report completion recording as blocked/uncertain, not done; inspect current bytes before any correction and never overwrite unrelated changes. Already-done historical bytes are not a new completion event. These checks provide procedural accountability, not atomic locking or host-enforced authorization; if concurrent mutation prevents current attribution, withhold the write.

When an existing project result location is available, preserve the completion references there with the exact Scope revision and original report/primary-evidence paths so later work can discover them. If references are session-local or retention is unavailable, state that limit instead of claiming durable retrieval. Do not copy a second verdict, modify the completed Scope or introduce a new evidence store.

Scope completion remains distinct from the entire approved request: Main checks all remaining required outcomes and the requested stop boundary under `iis-workflow`.

## Required result report

Return the following content through the ordinary completed-invocation result or report path, preserving actual observations and evidence references:

```text
SCOPE VERIFICATION RESULT
Project Root: <exact canonical root>
Scope: <exact canonical Scope path and pre-execution SHA256>
Thesis / Transition sources: <all exact bound paths and actual-byte SHA256; transition None when absent>
Independent invocation: <actual verifier identity and result/evidence reference>
Stable Target Paths: <exact paths and observed byte/runtime identities>
Scenario Effect Paths: <exact declared mutable paths and authorized effects>
Currentness before / after: <actual checks, byte/runtime identities and limitations>
Verification Verdict: VERIFIED | FAILED | INCONCLUSIVE
Verifier Scope Progression: PENDING CALLER RECORDING | NOT APPLICABLE
Observed Scope Status: ready | done

<semantic preflight, every authored Acceptance scenario, correction fresh/retained evidence boundary when applicable, actual actions/readbacks, execution method/environment identity, finding dispositions, durable reproducer locators, cleanup and exact limitations>
```

Record initial identities before execution, preserve raw observations, and distinguish measured facts from inference. Non-started preflight results name their exact blocker without inventing a semantic verdict. A normal evidence-complete `FAILED` does not need a provenance block; an authority/currentness/evidence/settlement limitation states `Decision`, `Governing authority`, `Observed condition`, `Effect` and `Next allowed action`.

For re-entry, identify the predecessor, actual correction attribution or evidence-only gap, evidence newly acquired versus retained with its original invocation attribution and current-applicability basis, execution handoff used, and any same-invocation usage correction. Explain reduced execution and remaining limits in the existing scenario report. For material findings needing corrective routing, preserve a usable reproducer or exact limitation and name the responsible role/current actor when supplied, permitted next action and unauthorized actions; this routing grants no new authority.
